package com.example.soulsandnether;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Random;

public class SoulSandNether extends JavaPlugin implements Listener {

    private static final int SOUL_SAND_LAYERS = 5;
    private static final int MAX_SOUL_SAND_HEIGHT = 128;
    private static final int ORE_ATTEMPTS_PER_CHUNK = 100;
    private final Random random = new Random();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        World world = event.getWorld();
        if (world.getEnvironment() != World.Environment.NETHER) return;

        int chunkX = event.getChunk().getX() << 4;
        int chunkZ = event.getChunk().getZ() << 4;

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int highestY = world.getHighestBlockYAt(chunkX + x, chunkZ + z) - 1;
                for (int y = 0; y < MAX_SOUL_SAND_HEIGHT && y <= highestY; y++) {
                    Block block = world.getBlockAt(chunkX + x, y, chunkZ + z);
                    if (y < SOUL_SAND_LAYERS) block.setType(Material.SOUL_SAND, false);
                }
            }
        }
    }
}
